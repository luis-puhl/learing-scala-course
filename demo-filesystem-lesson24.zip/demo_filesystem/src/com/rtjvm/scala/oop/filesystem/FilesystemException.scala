package com.rtjvm.scala.oop.filesystem

/**
  * Created by Daniel on 29-Oct-17.
  */
class FilesystemException(message: String) extends RuntimeException(message) {

}
